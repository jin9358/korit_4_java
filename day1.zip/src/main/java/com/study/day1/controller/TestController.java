package com.study.day1.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

// 일반 객체
@RestController
@RequiredArgsConstructor
public class TestController {

    @GetMapping
    public ResponseEntity<?> getTest() {
        return ResponseEntity.ok("test");
    }
}
